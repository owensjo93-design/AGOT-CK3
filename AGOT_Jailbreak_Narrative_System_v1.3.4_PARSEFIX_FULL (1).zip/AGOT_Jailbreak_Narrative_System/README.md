AGOT Jailbreak Narrative System — v1.3 REWORK (Full)
Required: A Game of Thrones (AGOT) + AGOT Cultural Personality Marriage AI

Highlights:
- Replaces flat jailbreak chance with a narrative escape chain (intrigue, brawl, ally).
- Only triggers aftermath on TRUE escapes (flag-gated); normal releases are unaffected.
- Post-escape outcomes:
  * Return home
  * Take the Black (switch to heir)
  * Playable Essos exile (with forced-travel beats)
- Golden Company:
  * Challenge Captain-General by duel
  * Win: remain playable
  * Lose but live: join company (on-map, non-playable), switch to landed kin
