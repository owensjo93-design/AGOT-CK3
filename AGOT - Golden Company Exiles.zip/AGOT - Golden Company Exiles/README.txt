AGOT - Golden Company Exiles
Version: 1.1.1

Premise
-------
Adds a chance for banished Westerosi characters (BANISH punishment, not Night's Watch) to end up in the Golden Company.
If the Golden Company cannot be detected in the current modset, the character may instead become a generic sellsword exile
with localization that defaults to a different mercenary company name, and NO Golden Company trait is applied.

Key Features
------------
- Hooks into on_character_banished
- Prowess-driven probability model (minimum prowess 6)
- If Golden Company is detectable:
  - Adds trait: Golden Company Exile
  - Moves the character to the Golden Company commander’s court
- If Golden Company is NOT detectable:
  - Does NOT add the trait
  - Adds a lightweight 'Sellsword Exile' modifier (localized to a fallback mercenary company name)
  - Attempts to move the character to a non–Golden Company mercenary title holder (when detectable)
- Compatibility-first: all moves are best-effort and gracefully no-op if titles/flags differ in your modset

Load Order
----------
Place anywhere after the main AGOT mod. Generally safe near other small gameplay submods.

