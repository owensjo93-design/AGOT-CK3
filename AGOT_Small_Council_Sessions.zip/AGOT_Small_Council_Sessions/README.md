AGOT: Small Council Sessions (v1.0.0)

Adds an annual Small Council meeting system with Westerosi-flavored proposals and outcomes, plus improved AI use of council invitations so minor houses are more likely to be called up when appropriate.

Requires: A Game of Thrones (CK3 total conversion)

Included workshop assets:
- workshop_assets/Small_Council_Sessions_workshop_under2MB.png
- workshop_assets/Small_Council_Sessions_workshop_under1MB.jpg

Game Rules
- Small Council Session Frequency: Yearly / Every Two Years / Every Three Years
- Councillor Exploits: Enabled / Disabled
- Eligible Rulers: Kings+ / Independent Dukes+

Notes
- All mechanics are designed as soft incentives (no hard locks) to encourage mixed councils.
